import { TerminalApp } from "@/components/terminal-app"

export default function Page() {
  return <TerminalApp />
}
