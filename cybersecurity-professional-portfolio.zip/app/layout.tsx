import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Shehzad Ali — Red Teamer & Vulnerability Researcher',
  description:
    'Portfolio of Shehzad Ali, red teamer and vulnerability researcher. OSCP, eWPTX, eCPPT, CEH, CPTS, ASCP. Offensive security, source-code auditing, and attack-surface research across web, API, mobile, AD, cloud, and AI/LLM.',
  generator: 'v0.app',
  keywords: [
    'Shehzad Ali',
    'penetration testing',
    'red team',
    'zero-day',
    'vulnerability research',
    'exploit development',
    'OSCP',
    'source code audit',
    'bug bounty',
    'AI LLM security',
  ],
  openGraph: {
    title: 'Shehzad Ali — Red Teamer & Vulnerability Researcher',
    description:
      'Red teamer & vulnerability researcher. Offensive security, source-code auditing, and attack-surface research.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0a0a0c',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`dark bg-background ${inter.variable} ${jetbrains.variable}`}>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
