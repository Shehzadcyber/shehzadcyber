// ============================================================================
// PORTFOLIO CONFIG — edit everything here.
// ============================================================================

export type Severity = "critical" | "high" | "medium" | "low"

export interface ResearchItem {
  id: string
  title: string
  severity: Severity
  summary: string
  details: string[]
}

export interface WriteupItem {
  id: string
  index: string
  title: string
  tag: string
  readTime: string
  summary: string
  body: string[]
}

export interface ArsenalGroup {
  label: string
  tools: string[]
}

export interface SocialLink {
  label: string
  href: string
  handle: string
}

export const config = {
  name: "SHEHZAD ALI",
  handle: "shehzad",
  host: "lab",
  roles: ["RED TEAMER", "VULNERABILITY RESEARCHER"],
  tagline: "Offensive Security · Vulnerability Research · Red Teaming",
  status: "ACTIVELY RESEARCHING",

  about: [
    "RED TEAMER",
    "VULNERABILITY RESEARCHER",
    "",
    "Focused on offensive security, vulnerability discovery,",
    "web security and attack-surface research. Source-code",
    "auditing and zero-day discovery across web, API, mobile,",
    "Active Directory, cloud, and AI/LLM systems.",
  ],

  certs: ["OSCP", "eWPTX", "eCPPT", "ASCP", "CPTS", "CEH"],

  research: [
    {
      id: "web",
      title: "Web Application Security",
      severity: "critical",
      summary: "Deep source-code audits and logic-flaw discovery across modern web stacks.",
      details: [
        "Auth bypass, IDOR, and access-control chains in complex multi-tenant apps.",
        "Server-side template injection and deserialization gadget discovery.",
        "Full request-lifecycle review: parsers, middleware, and trust boundaries.",
      ],
    },
    {
      id: "api",
      title: "API Security",
      severity: "high",
      summary: "REST / GraphQL attack-surface mapping and broken-object-level authorization.",
      details: [
        "BOLA / BFLA discovery across versioned and undocumented endpoints.",
        "Mass assignment, rate-limit bypass, and token-scope escalation.",
        "Schema introspection abuse and GraphQL batching attacks.",
      ],
    },
    {
      id: "vr",
      title: "Vulnerability Research",
      severity: "high",
      summary: "Binary and source-level research toward reproducible zero-day discovery.",
      details: [
        "Coverage-guided fuzzing harness design and crash triage.",
        "Root-cause analysis and reliable exploit primitive construction.",
        "Coordinated disclosure and CVE assignment workflow.",
      ],
    },
    {
      id: "asm",
      title: "Attack Surface Research",
      severity: "medium",
      summary: "External recon and exposure mapping across large, changing perimeters.",
      details: [
        "Asset discovery, subdomain enumeration, and drift monitoring.",
        "Exposed service and secret detection at scale.",
        "Prioritization by exploitability and blast radius.",
      ],
    },
  ] as ResearchItem[],

  writeups: [
    {
      id: "auth",
      index: "01",
      title: "Authentication Research",
      tag: "web",
      readTime: "8 min",
      summary: "Breaking a session model that assumed the client would behave.",
      body: [
        "// DEMO CONTENT — placeholder write-up, not a real disclosure.",
        "A review of a multi-step authentication flow where an intermediate",
        "state token was trusted after partial verification, allowing a full",
        "session to be minted without completing the second factor.",
        "Covers the trust boundary, the missing server-side state check, and the",
        "minimal request sequence that reproduces the bypass.",
      ],
    },
    {
      id: "ssrf",
      index: "02",
      title: "SSRF Research",
      tag: "web / cloud",
      readTime: "11 min",
      summary: "From a benign URL preview to cloud metadata and beyond.",
      body: [
        "// DEMO CONTENT — placeholder write-up, not a real disclosure.",
        "Walkthrough of a server-side request forgery that started in an image",
        "fetcher and escalated through redirect chains and DNS rebinding into",
        "the internal network and instance metadata service.",
        "Includes the filter-bypass payloads and the defensive fix.",
      ],
    },
    {
      id: "apisec",
      index: "03",
      title: "API Security",
      tag: "api",
      readTime: "7 min",
      summary: "Object-level authorization that only checked the front door.",
      body: [
        "// DEMO CONTENT — placeholder write-up, not a real disclosure.",
        "How a versioned API exposed a legacy endpoint that skipped the",
        "object-ownership check present on its newer counterpart, enabling",
        "cross-tenant data access via a predictable identifier.",
      ],
    },
    {
      id: "rce",
      index: "04",
      title: "RCE Research",
      tag: "binary",
      readTime: "14 min",
      summary: "Turning a memory-safety bug into a reliable primitive.",
      body: [
        "// DEMO CONTENT — placeholder write-up, not a real disclosure.",
        "Root-cause analysis of a heap corruption reached through a malformed",
        "input parser, and the steps taken to build a reliable exploitation",
        "primitive under modern mitigations.",
      ],
    },
  ] as WriteupItem[],

  arsenal: [
    { label: "RECON", tools: ["Nmap", "ffuf", "httpx"] },
    { label: "WEB", tools: ["Burp Suite", "Nuclei"] },
    { label: "RESEARCH", tools: ["Ghidra", "Wireshark"] },
    { label: "CODE", tools: ["Python", "Go", "Bash"] },
    { label: "OS", tools: ["Linux", "Docker"] },
  ] as ArsenalGroup[],

  socials: [
    { label: "GitHub", href: "https://github.com/Shehzadcyber", handle: "@Shehzadcyber" },
    { label: "LinkedIn", href: "#", handle: "add-your-link" },
    { label: "X", href: "#", handle: "add-your-handle" },
    { label: "Email", href: "mailto:you@example.com", handle: "you@example.com" },
  ] as SocialLink[],
}

export type SectionId = "home" | "about" | "research" | "writeups" | "arsenal" | "contact"

export const navCommands: { id: SectionId; cmd: string }[] = [
  { id: "about", cmd: "/about" },
  { id: "research", cmd: "/research" },
  { id: "writeups", cmd: "/writeups" },
  { id: "arsenal", cmd: "/arsenal" },
  { id: "contact", cmd: "/contact" },
]
