"use client"

import { useState } from "react"
import { AnimatePresence, motion } from "motion/react"
import { ArrowLeft, ExternalLink } from "lucide-react"
import {
  config,
  type ResearchItem,
  type Severity,
  type WriteupItem,
} from "@/lib/portfolio-config"

const ease = [0.22, 1, 0.36, 1] as const

const severityStyles: Record<Severity, { text: string; border: string; label: string }> = {
  critical: { text: "text-primary", border: "border-primary/40", label: "CRITICAL" },
  high: { text: "text-amber", border: "border-amber/40", label: "HIGH" },
  medium: { text: "text-terminal", border: "border-terminal/40", label: "MEDIUM" },
  low: { text: "text-muted-foreground", border: "border-border", label: "LOW" },
}

function PromptLine({ cmd }: { cmd: string }) {
  return (
    <p className="mb-6 text-sm text-muted-foreground">
      <span className="text-terminal">{config.handle}@{config.host}</span>
      <span className="text-muted-foreground">:</span>
      <span className="text-primary">~</span>
      <span className="text-muted-foreground">$ </span>
      <span className="text-foreground">{cmd}</span>
    </p>
  )
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <h2 className="mb-8 font-mono text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
      {children}
    </h2>
  )
}

// ---------------------------------------------------------------------------

export function AboutPanel() {
  return (
    <div>
      <PromptLine cmd="/about" />
      <SectionHeading>whoami</SectionHeading>
      <div className="max-w-2xl space-y-1 font-mono text-sm leading-relaxed text-muted-foreground sm:text-base">
        {config.about.map((line, i) =>
          line === "" ? (
            <div key={i} className="h-3" />
          ) : (
            <p
              key={i}
              className={
                i < 2 ? "text-lg font-semibold tracking-wide text-foreground sm:text-xl" : ""
              }
            >
              {line}
            </p>
          ),
        )}
      </div>

      <div className="mt-8 flex flex-wrap gap-2">
        {config.certs.map((c) => (
          <span
            key={c}
            className="border border-border px-2.5 py-1 font-mono text-xs text-muted-foreground"
          >
            {c}
          </span>
        ))}
      </div>

      <p className="mt-8 flex items-center gap-2 font-mono text-sm">
        <span className="text-muted-foreground">STATUS:</span>
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-terminal opacity-70" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-terminal" />
        </span>
        <span className="text-terminal">{config.status}</span>
      </p>
    </div>
  )
}

// ---------------------------------------------------------------------------

export function ResearchPanel() {
  const [active, setActive] = useState<ResearchItem | null>(null)

  return (
    <div>
      <PromptLine cmd="/research" />
      <SectionHeading>CURRENT RESEARCH</SectionHeading>

      <AnimatePresence mode="wait">
        {active ? (
          <motion.div
            key="detail"
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.25, ease }}
          >
            <button
              onClick={() => setActive(null)}
              className="mb-6 inline-flex items-center gap-2 font-mono text-xs text-muted-foreground transition-colors hover:text-terminal"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> back
            </button>
            <div className={`border-l-2 pl-5 ${severityStyles[active.severity].border}`}>
              <div className="mb-2 flex items-center gap-3">
                <span
                  className={`font-mono text-xs ${severityStyles[active.severity].text}`}
                >
                  [ {severityStyles[active.severity].label} ]
                </span>
              </div>
              <h3 className="mb-4 text-xl font-bold text-foreground">{active.title}</h3>
              <p className="mb-6 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                {active.summary}
              </p>
              <ul className="max-w-2xl space-y-2">
                {active.details.map((d, i) => (
                  <li key={i} className="flex gap-3 text-sm leading-relaxed text-muted-foreground">
                    <span className="mt-1 text-terminal">&gt;</span>
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="grid gap-3 sm:grid-cols-2"
          >
            {config.research.map((r) => (
              <button
                key={r.id}
                onClick={() => setActive(r)}
                className={`group border ${severityStyles[r.severity].border} bg-card/40 p-5 text-left transition-all hover:bg-card hover:-translate-y-0.5`}
              >
                <div className="mb-3 flex items-center justify-between">
                  <span className={`font-mono text-xs ${severityStyles[r.severity].text}`}>
                    [ {severityStyles[r.severity].label} ]
                  </span>
                  <span className="font-mono text-xs text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">
                    expand &rarr;
                  </span>
                </div>
                <h3 className="mb-2 text-base font-semibold text-foreground">{r.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{r.summary}</p>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// ---------------------------------------------------------------------------

export function WriteupsPanel() {
  const [active, setActive] = useState<WriteupItem | null>(null)

  return (
    <div>
      <PromptLine cmd="/writeups" />
      <SectionHeading>WRITE-UPS</SectionHeading>

      <AnimatePresence mode="wait">
        {active ? (
          <motion.div
            key="detail"
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.25, ease }}
          >
            <button
              onClick={() => setActive(null)}
              className="mb-6 inline-flex items-center gap-2 font-mono text-xs text-muted-foreground transition-colors hover:text-terminal"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> back
            </button>
            <div className="flex items-center gap-3 font-mono text-xs text-muted-foreground">
              <span className="text-primary">{active.index}</span>
              <span className="border border-border px-2 py-0.5">{active.tag}</span>
              <span>{active.readTime}</span>
            </div>
            <h3 className="mb-5 mt-4 text-xl font-bold text-foreground">{active.title}</h3>
            <div className="max-w-2xl space-y-3 border-l-2 border-border pl-5">
              {active.body.map((p, i) => (
                <p
                  key={i}
                  className={`text-sm leading-relaxed ${
                    p.startsWith("//") ? "text-amber" : "text-muted-foreground"
                  }`}
                >
                  {p}
                </p>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.ul
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="divide-y divide-border border-y border-border"
          >
            {config.writeups.map((w) => (
              <li key={w.id}>
                <button
                  onClick={() => setActive(w)}
                  className="group flex w-full items-center gap-4 py-4 text-left transition-colors hover:bg-card/50"
                >
                  <span className="font-mono text-sm text-primary">{w.index}</span>
                  <span className="flex-1">
                    <span className="block text-base font-medium text-foreground group-hover:text-terminal">
                      {w.title}
                    </span>
                    <span className="block text-sm text-muted-foreground">{w.summary}</span>
                  </span>
                  <span className="hidden font-mono text-xs text-muted-foreground sm:inline">
                    {w.readTime}
                  </span>
                  <span className="font-mono text-xs text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">
                    read &rarr;
                  </span>
                </button>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  )
}

// ---------------------------------------------------------------------------

export function ArsenalPanel() {
  return (
    <div>
      <PromptLine cmd="/arsenal" />
      <SectionHeading>ARSENAL</SectionHeading>
      <div className="max-w-2xl divide-y divide-border border-y border-border font-mono">
        {config.arsenal.map((group) => (
          <div key={group.label} className="flex flex-col gap-1 py-4 sm:flex-row sm:items-baseline sm:gap-6">
            <span className="w-28 shrink-0 text-sm font-semibold tracking-wider text-terminal">
              {group.label}
            </span>
            <span className="text-sm text-muted-foreground">
              {group.tools.join("  ·  ")}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------

export function ContactPanel() {
  return (
    <div>
      <PromptLine cmd="/contact" />
      <SectionHeading>CONNECT</SectionHeading>
      <ul className="max-w-md divide-y divide-border border-y border-border">
        {config.socials.map((s) => (
          <li key={s.label}>
            <a
              href={s.href}
              target={s.href.startsWith("http") ? "_blank" : undefined}
              rel="noreferrer"
              className="group flex items-center justify-between py-4 transition-colors hover:text-terminal"
            >
              <span className="text-base font-medium text-foreground group-hover:text-terminal">
                {s.label}
              </span>
              <span className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
                {s.handle}
                <ExternalLink className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
              </span>
            </a>
          </li>
        ))}
      </ul>
      <p className="mt-8 font-mono text-sm">
        <span className="text-terminal">{config.handle}@{config.host}</span>
        <span className="text-muted-foreground">:</span>
        <span className="text-primary">~</span>
        <span className="text-muted-foreground">$ </span>
        <span className="text-foreground">connect</span>
        <span className="cursor-blink ml-1 inline-block h-4 w-2 translate-y-0.5 bg-terminal" />
      </p>
    </div>
  )
}
