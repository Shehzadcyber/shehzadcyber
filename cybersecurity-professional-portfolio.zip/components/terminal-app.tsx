"use client"

import { useEffect, useRef, useState } from "react"
import { AnimatePresence, motion } from "motion/react"
import { config, navCommands, type SectionId } from "@/lib/portfolio-config"
import {
  AboutPanel,
  ArsenalPanel,
  ContactPanel,
  ResearchPanel,
  WriteupsPanel,
} from "@/components/panels"

const ease = [0.22, 1, 0.36, 1] as const

// map both /command and bare command → section
const commandMap: Record<string, SectionId | "clear" | "help"> = {
  about: "about",
  "/about": "about",
  research: "research",
  "/research": "research",
  writeups: "writeups",
  "/writeups": "writeups",
  arsenal: "arsenal",
  "/arsenal": "arsenal",
  contact: "contact",
  "/contact": "contact",
  home: "home",
  "/home": "home",
  clear: "clear",
  help: "help",
}

function Hero({ onEnter }: { onEnter: () => void }) {
  return (
    <div>
      <p className="mb-8 text-sm text-muted-foreground">
        <span className="text-terminal">{config.handle}@{config.host}</span>
        <span className="text-muted-foreground">:</span>
        <span className="text-primary">~</span>
        <span className="text-muted-foreground">$ </span>
        <span className="text-foreground">whoami</span>
      </p>

      <h1 className="text-balance text-5xl font-bold tracking-tight text-foreground sm:text-7xl">
        {config.name}
      </h1>

      <div className="mt-6 space-y-1">
        {config.roles.map((r) => (
          <p key={r} className="font-mono text-lg tracking-widest text-terminal sm:text-xl">
            {r}
          </p>
        ))}
      </div>

      <p className="mt-8 max-w-xl text-pretty font-mono text-sm text-muted-foreground sm:text-base">
        {config.tagline}
      </p>

      <button
        onClick={onEnter}
        className="group mt-10 inline-flex items-center gap-2 border border-terminal/50 bg-terminal/5 px-6 py-3 font-mono text-sm text-terminal transition-all hover:bg-terminal/15 hover:-translate-y-0.5"
      >
        [ ENTER LAB ]
        <span className="cursor-blink inline-block h-4 w-2 bg-terminal transition-opacity group-hover:opacity-100" />
      </button>
    </div>
  )
}

export function TerminalApp() {
  const [section, setSection] = useState<SectionId>("home")
  const [history, setHistory] = useState<{ text: string; error?: boolean }[]>([])
  const [input, setInput] = useState("")
  const [cmdLog, setCmdLog] = useState<string[]>([])
  const [logIdx, setLogIdx] = useState(-1)
  const inputRef = useRef<HTMLInputElement>(null)

  const go = (id: SectionId) => setSection(id)

  const runCommand = (raw: string) => {
    const cmd = raw.trim().toLowerCase()
    if (!cmd) return
    setCmdLog((l) => [...l, cmd])
    setLogIdx(-1)

    const target = commandMap[cmd]
    if (target === undefined) {
      setHistory((h) => [
        ...h,
        { text: `$ ${cmd}` },
        { text: `command not found: ${cmd} — type 'help'`, error: true },
      ])
      return
    }
    if (target === "clear") {
      setHistory([])
      return
    }
    if (target === "help") {
      setHistory((h) => [
        ...h,
        { text: "$ help" },
        { text: "available: about research writeups arsenal contact home clear help" },
      ])
      return
    }
    setHistory((h) => [...h, { text: `$ ${cmd}` }])
    setSection(target)
  }

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.nativeEvent.isComposing || e.keyCode === 229) return
    if (e.key === "Enter") {
      runCommand(input)
      setInput("")
    } else if (e.key === "ArrowUp") {
      e.preventDefault()
      if (!cmdLog.length) return
      const next = logIdx < 0 ? cmdLog.length - 1 : Math.max(0, logIdx - 1)
      setLogIdx(next)
      setInput(cmdLog[next])
    } else if (e.key === "ArrowDown") {
      e.preventDefault()
      if (logIdx < 0) return
      const next = logIdx + 1
      if (next >= cmdLog.length) {
        setLogIdx(-1)
        setInput("")
      } else {
        setLogIdx(next)
        setInput(cmdLog[next])
      }
    }
  }

  // Escape returns to home from any section
  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape" && section !== "home") setSection("home")
    }
    window.addEventListener("keydown", onEsc)
    return () => window.removeEventListener("keydown", onEsc)
  }, [section])

  const panels: Record<Exclude<SectionId, "home">, React.ReactNode> = {
    about: <AboutPanel />,
    research: <ResearchPanel />,
    writeups: <WriteupsPanel />,
    arsenal: <ArsenalPanel />,
    contact: <ContactPanel />,
  }

  return (
    <main className="relative min-h-screen bg-background">
      <div className="scanlines pointer-events-none fixed inset-0 z-30 opacity-40" aria-hidden />
      <div className="bg-grid pointer-events-none fixed inset-0 opacity-30" aria-hidden />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-5xl flex-col px-4 py-6 sm:px-8 sm:py-10">
        {/* terminal window frame */}
        <div className="flex flex-1 flex-col border border-border bg-card/30 backdrop-blur-sm">
          {/* title bar */}
          <div className="flex items-center gap-2 border-b border-border px-4 py-3">
            <span className="h-3 w-3 rounded-full bg-primary/70" />
            <span className="h-3 w-3 rounded-full bg-amber/70" />
            <span className="h-3 w-3 rounded-full bg-terminal/70" />
            <span className="ml-3 font-mono text-xs text-muted-foreground">
              {config.handle}@{config.host}: ~/portfolio
            </span>
          </div>

          {/* nav */}
          <nav className="flex flex-wrap items-center gap-x-1 gap-y-2 border-b border-border px-4 py-3">
            <button
              onClick={() => go("home")}
              className={`font-mono text-sm tracking-tight transition-colors ${
                section === "home" ? "text-terminal" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              [ {config.handle} ]
            </button>
            <span className="mx-2 hidden text-border sm:inline">|</span>
            <div className="flex flex-wrap gap-x-4 gap-y-1">
              {navCommands.map((n) => {
                const activeCmd = section === n.id
                return (
                  <button
                    key={n.id}
                    onClick={() => go(n.id)}
                    className={`relative font-mono text-sm transition-colors ${
                      activeCmd ? "text-terminal" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {n.cmd}
                    {activeCmd && (
                      <motion.span
                        layoutId="nav-active"
                        className="absolute -bottom-1 left-0 h-px w-full bg-terminal"
                        transition={{ duration: 0.3, ease }}
                      />
                    )}
                  </button>
                )
              })}
            </div>
          </nav>

          {/* content panel */}
          <div className="flex-1 overflow-hidden px-5 py-8 sm:px-10 sm:py-12">
            <AnimatePresence mode="wait">
              <motion.div
                key={section}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3, ease }}
              >
                {section === "home" ? <Hero onEnter={() => go("about")} /> : panels[section]}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* interactive terminal input */}
          <div
            className="border-t border-border px-4 py-3"
            onClick={() => inputRef.current?.focus()}
          >
            {history.length > 0 && (
              <div className="mb-2 max-h-24 space-y-0.5 overflow-y-auto font-mono text-xs">
                {history.map((h, i) => (
                  <p key={i} className={h.error ? "text-primary" : "text-muted-foreground"}>
                    {h.text}
                  </p>
                ))}
              </div>
            )}
            <div className="flex items-center gap-2 font-mono text-sm">
              <span className="shrink-0 text-terminal">{config.handle}@{config.host}</span>
              <span className="shrink-0 text-muted-foreground">:</span>
              <span className="shrink-0 text-primary">~</span>
              <span className="shrink-0 text-muted-foreground">$</span>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKeyDown}
                spellCheck={false}
                autoComplete="off"
                aria-label="terminal command input"
                placeholder="type 'help'"
                className="w-full bg-transparent text-foreground caret-terminal outline-none placeholder:text-muted-foreground/50"
              />
            </div>
          </div>
        </div>

        <p className="mt-4 text-center font-mono text-xs text-muted-foreground/60">
          click a command, type in the terminal, or press{" "}
          <span className="text-muted-foreground">ESC</span> to return home
        </p>
      </div>
    </main>
  )
}
